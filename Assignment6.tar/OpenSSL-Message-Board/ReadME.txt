Group:
	Neil Malu
	Kiran Kurian
	Dhruv Bhardwaj
	Tomer Levy

Assignment 6 - OpenSSL Message Board


Instructions:

1)	Run server.py and client.py on different terminals. Make sure that the server is running first.

2)	At the prompt, enter a username and password. If you are a first time user, a new user will be created with the password you entered. 

3)	Once logged in, you will be prompted to either GET messages, POST a message or END your session. You will be logged out but can log back in

4)	Hit control + C to end the session and the client program at any time. Make sure the client is closed before the server or address will still be reserved on the server